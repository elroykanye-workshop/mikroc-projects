int i = 0;
int lim = 9;
const int delay = 1000;

void Display(int val) {
     switch (val) {
            case 0:
                 PORTA=0b00111111;
                 break;
            case 1:
                 PORTB=0b00000110;
                 break;
            case 2:
                 PORTB=0b01011011;
                 break;
            case 3:
                 PORTB=0b01001111;
                 break;
            case 4:
                 PORTB=0b01100110;
                 break;
            case 5:
                 PORTB=0b01101101;
                 break;
            case 6:
                 PORTB=0b01111101;
                 break;
            case 7:
                 PORTB=0b00000111;
                 break;
            case 8:
                 PORTB=0b01111111;
                 break;
            case 9:
                 PORTB=0b01101111;
                 break;
     }
}

void CountDown() {
     do {
               Display(i);
               Delay_ms(delay);
               i = i - 1;
     } while(i >= 0);
}


Pressing() {

     if(Button(&PORTA, 0, 100, 0)) {
                i = 0;
                Display(i);
     }

     if(Button(&PORTA, 1, 100, 0)) {
                if (i < lim) {
                   i = i + 1;
                   Display(i);
                }
     }

     if(Button(&PORTA, 2, 100, 0)) {
                if (i == lim) {
                   CountDown();
                }
     }
     
     if(Button(&PORTA, 3, 100, 0)) {
                       Sound_Play(100, 500);
     }

}

void main() {
     TRISB=0x00;
     TRISA=0x1F;

     Sound_Init(&PORTB, 7);
     PORTB=0b00000000;
     while (1) {
           Pressing();
     }

}
